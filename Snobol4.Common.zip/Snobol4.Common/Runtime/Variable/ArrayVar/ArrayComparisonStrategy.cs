﻿namespace Snobol4.Common;

public class ArrayComparisonStrategy : IComparisonStrategy
{

    public int CompareTo(Var self, Var? other)
    {
        if (other is null)
            return 1; // Non-null is always greater than null

        // Arrays of the same type compare by creation time
        if (other is ArrayVar)
        {
            return self.SequenceId.CompareTo(other.SequenceId);
        }

        // Different types compare by type name (lexicographically)
        return string.Compare(self.DataType(), other.DataType(), StringComparison.InvariantCulture);
    }


    public bool Equals(Var self, Var other)
    {
        // Arrays are only equal if they're the same instance
        return IsIdentical(self, other);
    }


    public bool IsIdentical(Var self, Var other)
    {
        // Arrays are identical only if they have the same unique ID
        return other is not null && other.SequenceId == self.SequenceId;
    }
}